import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VerproductoPage } from './verproducto';

@NgModule({
  declarations: [
    VerproductoPage,
  ],
  imports: [
    IonicPageModule.forChild(VerproductoPage),
  ],
})
export class VerproductoPageModule {}
