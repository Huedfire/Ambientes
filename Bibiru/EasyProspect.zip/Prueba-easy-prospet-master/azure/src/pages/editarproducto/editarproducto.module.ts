import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditarproductoPage } from './editarproducto';

@NgModule({
  declarations: [
    EditarproductoPage,
  ],
  imports: [
    IonicPageModule.forChild(EditarproductoPage),
  ],
})
export class EditarproductoPageModule {}
