declare var process: { env: { [key: string]: string | undefined; } };
