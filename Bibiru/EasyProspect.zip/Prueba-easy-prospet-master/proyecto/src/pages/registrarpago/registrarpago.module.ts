import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RegistrarpagoPage } from './registrarpago';

@NgModule({
  declarations: [
    RegistrarpagoPage,
  ],
  imports: [
    IonicPageModule.forChild(RegistrarpagoPage),
  ],
})
export class RegistrarpagoPageModule {}
