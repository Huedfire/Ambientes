import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EdiatarnotificacionPage } from './ediatarnotificacion';

@NgModule({
  declarations: [
    EdiatarnotificacionPage,
  ],
  imports: [
    IonicPageModule.forChild(EdiatarnotificacionPage),
  ],
})
export class EdiatarnotificacionPageModule {}
