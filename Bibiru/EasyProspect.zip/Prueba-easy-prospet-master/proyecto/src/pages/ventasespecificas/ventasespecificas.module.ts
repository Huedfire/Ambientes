import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VentasespecificasPage } from './ventasespecificas';

@NgModule({
  declarations: [
    VentasespecificasPage,
  ],
  imports: [
    IonicPageModule.forChild(VentasespecificasPage),
  ],
})
export class VentasespecificasPageModule {}
