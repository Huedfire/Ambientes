import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VerventasPage } from './verventas';

@NgModule({
  declarations: [
    VerventasPage,
  ],
  imports: [
    IonicPageModule.forChild(VerventasPage),
  ],
})
export class VerventasPageModule {}
