import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VertareasPage } from './vertareas';

@NgModule({
  declarations: [
    VertareasPage,
  ],
  imports: [
    IonicPageModule.forChild(VertareasPage),
  ],
})
export class VertareasPageModule {}
