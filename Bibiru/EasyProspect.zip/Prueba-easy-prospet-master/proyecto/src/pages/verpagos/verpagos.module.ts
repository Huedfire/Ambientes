import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VerpagosPage } from './verpagos';

@NgModule({
  declarations: [
    VerpagosPage,
  ],
  imports: [
    IonicPageModule.forChild(VerpagosPage),
  ],
})
export class VerpagosPageModule {}
