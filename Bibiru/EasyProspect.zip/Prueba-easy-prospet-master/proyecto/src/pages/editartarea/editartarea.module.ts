import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditartareaPage } from './editartarea';

@NgModule({
  declarations: [
    EditartareaPage,
  ],
  imports: [
    IonicPageModule.forChild(EditartareaPage),
  ],
})
export class EditartareaPageModule {}
